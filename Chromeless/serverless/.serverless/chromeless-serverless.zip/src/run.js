const launch = require('@serverless-chrome/lambda')

const handler = require('./lke0vk7vt8___run.js')
const options = {  }

module.exports.default = function ensureHeadlessChrome (event, context, callback) {
  launch(options)
    .then((instance) => {
      handler.default(event, context, callback, instance)
    })
    .catch((error) => {
      console.error(
        'Error occured in serverless-plugin-chrome wrapper when trying to ' +
          'ensure Chrome for default() handler.',
        options,
        error
      )
    })
}